/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projekakhir;

/**
 *
 * @author ACER
 */
public class ProjekAkhir {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       LoginView mv = new LoginView();
        mv.setVisible(true);
        mv.setLocationRelativeTo(null);
    }
    
}
